const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

const usuarioRoutes = require('./routes/usuario.routes');
app.use('/usuarios', usuarioRoutes);

app.get('/', (req, res) => {
    res.json({ mensaje: 'API de usuarios funcionando' });
});

app.listen(3000, () => {
    console.log('Servidor corriendo en http://localhost:3000');
});
