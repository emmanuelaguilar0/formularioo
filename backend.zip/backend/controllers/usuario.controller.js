const usuarioService = require('../services/usuario.service');

exports.getAll = (req, res) => {
    usuarioService.getAll((err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
};

exports.getById = (req, res) => {
    usuarioService.getById(req.params.id, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        if (results.length === 0) return res.status(404).json({ mensaje: 'Usuario no encontrado' });
        res.json(results[0]);
    });
};

exports.create = (req, res) => {
    const usuario = req.body;

    usuarioService.findByDocumento(usuario.tipoDocumento, usuario.documento, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        if (results.length > 0) {
            return res.status(409).json({ mensaje: 'Ya existe un usuario con ese tipo y número de documento.' });
        }

        usuarioService.create(usuario, (err, result) => {
            if (err) return res.status(500).json({ error: err.message });
            res.status(201).json({ id: result.insertId, ...usuario });
        });
    });
};

exports.update = (req, res) => {
    const usuario = req.body;

    usuarioService.findByDocumento(usuario.tipoDocumento, usuario.documento, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });

        const duplicado = results.find(item => String(item.id) !== String(req.params.id));
        if (duplicado) {
            return res.status(409).json({ mensaje: 'Ya existe otro usuario con ese tipo y número de documento.' });
        }

        usuarioService.update(req.params.id, usuario, (err, result) => {
            if (err) return res.status(500).json({ error: err.message });
            if (result.affectedRows === 0) return res.status(404).json({ mensaje: 'Usuario no encontrado' });
            res.json({ mensaje: 'Usuario actualizado' });
        });
    });
};

exports.delete = (req, res) => {
    usuarioService.delete(req.params.id, (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        if (result.affectedRows === 0) return res.status(404).json({ mensaje: 'Usuario no encontrado' });
        res.json({ mensaje: 'Usuario eliminado' });
    });
};
