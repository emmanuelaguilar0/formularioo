const db = require('../config/db');

exports.getAll = (callback) => {
    db.query('SELECT * FROM usuarios ORDER BY id DESC', callback);
};

exports.getById = (id, callback) => {
    db.query('SELECT * FROM usuarios WHERE id = ?', [id], callback);
};

exports.findByDocumento = (tipoDocumento, documento, callback) => {
    db.query(
        'SELECT * FROM usuarios WHERE tipoDocumento = ? AND documento = ?',
        [tipoDocumento, documento],
        callback
    );
};

exports.create = (usuario, callback) => {
    db.query(
        `INSERT INTO usuarios
        (tipoDocumento, documento, nombres, apellidos, direccion, ciudad, fecha, correo)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [
            usuario.tipoDocumento,
            usuario.documento,
            usuario.nombres,
            usuario.apellidos,
            usuario.direccion,
            usuario.ciudad,
            usuario.fecha || null,
            usuario.correo
        ],
        callback
    );
};

exports.update = (id, usuario, callback) => {
    db.query(
        `UPDATE usuarios SET
        tipoDocumento=?, documento=?, nombres=?, apellidos=?, direccion=?, ciudad=?, fecha=?, correo=?
        WHERE id=?`,
        [
            usuario.tipoDocumento,
            usuario.documento,
            usuario.nombres,
            usuario.apellidos,
            usuario.direccion,
            usuario.ciudad,
            usuario.fecha || null,
            usuario.correo,
            id
        ],
        callback
    );
};

exports.delete = (id, callback) => {
    db.query('DELETE FROM usuarios WHERE id=?', [id], callback);
};
